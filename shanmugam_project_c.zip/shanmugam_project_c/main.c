#include<stdio.h>
int items[100];
int cust_id = 0;
long long int ph;
char name[255];

int price[10] = {20, 14, 40, 10, 49, 12, 92, 63, 17, 20};

int salt=100;
int maggi=150;
int sugar=50;
int oreo=60;
int jam=20;
int milk=30;
int rice=80;
int atta=70;
int oats=50;
int juice=200;

void get_userdata()
{
    printf("\nEnter your name: ");
    scanf("%s",name);
    printf("\nEnter customerID: ");
    scanf("%d",&cust_id);
    printf("\nEnter phone number: ");
    scanf("%lld",&ph);
    printf("-------------------------\n");
    display_data();
}

void display_data()
{
    int i = 2;
    printf("\nYour name: %s",name);
    printf("\nYour customerID %d", cust_id);
    printf("\nYour phone number: %lld\n", ph);
    printf("\nConfirm with 1 if the data is correct else press 0\n");
    scanf("%d",&i);

    if(i == 1)
    {
        display_items();
    }
    else if(i == 0)
    {
        printf("-------Re-enter your data------\n");
        get_userdata();
    }
    else
    {
        //do nothing
    }
}

void display_items()
{
    char items[][10] = {"salt(kg)","maggi(pk)","suagr(kg)","oreo(pk)","jam(pk)","milk(l)","rice(kg)","atta(kg)","oats(g)","juice(L)"};
    int stock[10] = {100,150,50,60,20,30,80,70,50,200};


    printf("\n********************************\n");
    printf("|ITEMS|   \t|STOCK| |PRICE|\n");
    for(int i = 0; i < 10; i++)
    {
        printf("%d %s  \t:%d  \t %d\n",(i+1),items[i],stock[i],price[i]);
    }
    printf("Press 0 to exit\n");
    printf("********************************\n");
    get_input();

}

void get_input()
{
    int qty = 1;
    int choice = 0;
    int i = 1;
    int sum = 0;
    int indsum = 0;
    while( i == 1)
    {
        printf("\n-------------------------------\n");
        printf("---------Enter-choice----------\n");
        printf("-------------------------------\n");
        scanf("\n%d",&choice);
        switch(choice)
        {
        case 1:
            printf("Enter the quantity required for Salt: ");
            scanf("%d",&qty);
            if(qty>salt){
                printf("OUT OF STOCK");
                break;
            }

            indsum = price[0]*qty;
            printf("Price of item for %d Quantities: %d\n",qty,indsum);
            sum = sum + (price[0])*qty;
            printf("Total cart Sum: %d\n",sum);
            salt = salt - qty;
            printf("-------------------------------\n");
            break;

         case 2:
            printf("Enter the quantity required for Maggi: ");
            scanf("%d",&qty);
            if(qty>maggi){
                printf("OUT OF STOCK");
                break;
            }
            indsum = (price[1])*qty;
            printf("Price of item for %d Quantities: %d\n",qty,indsum);
            sum = sum + (price[1])*qty;
            printf("Total cart Sum: %d\n",sum);
            maggi = maggi - qty;
            printf("-------------------------------\n");
            break;

         case 3:
            printf("Enter the quantity required for Sugar: ");
            scanf("%d",&qty);
            if(qty>sugar){
                printf("OUT OF STOCK");
                break;
            }
            indsum = (price[2])*qty;
            printf("Price of item for %d Quantities: %d\n",qty,indsum);
            sum = sum + (price[2])*qty;
            printf("Total cart Sum: %d\n",sum);
            sugar = sugar - qty;
            printf("-------------------------------\n");
            break;

         case 4:
            printf("Enter the quantity required for Oreo: ");
            scanf("%d",&qty);
            if(qty>oreo){
                printf("OUT OF STOCK");
                break;
            }
            indsum = (price[3])*qty;
            printf("Price of item for %d Quantities: %d\n",qty,indsum);
            sum = sum + (price[3])*qty;
            printf("Total cart Sum: %d\n",sum);
            oreo = oreo - qty;
            printf("-------------------------------\n");
            break;

         case 5:
            printf("Enter the quantity required for Jam: ");
            scanf("%d",&qty);
            if(qty>jam){
                printf("OUT OF STOCK");
                break;
            }
            indsum = (price[4])*qty;
            printf("Price of item for %d Quantities: %d\n",qty,indsum);
            sum = sum + (price[4])*qty;
            printf("Total cart Sum: %d\n",sum);
            jam = jam - qty;
            printf("-------------------------------\n");
            break;

         case 6:
            printf("Enter the quantity required for milk: ");
            scanf("%d",&qty);
            if(qty>milk){
                printf("OUT OF STOCK");
                break;
            }
            indsum = (price[5])*qty;
            printf("Price of item for %d Quantities: %d\n",qty,indsum);
            sum = sum + (price[5])*qty;
            printf("Total cart Sum: %d\n",sum);
            milk = milk - qty;
            printf("-------------------------------\n");
            break;

         case 7:
            printf("Enter the quantity required for rice: ");
            scanf("%d",&qty);
            if(qty>rice){
                printf("OUT OF STOCK");
                break;
            }
            indsum = (price[6])*qty;
            printf("Price of item for %d Quantities: %d\n",qty,indsum);
            sum = sum + (price[6])*qty;
            printf("Total cart Sum: %d\n",sum);
            rice = rice - qty;
            printf("-------------------------------\n");
            break;

         case 8:
            printf("Enter the quantity required for atta: ");
            scanf("%d",&qty);
            if(qty>atta){
                printf("OUT OF STOCK");
                break;
            }
            indsum = (price[7])*qty;
            printf("Price of item for %d Quantities: %d\n",qty,indsum);
            sum = sum + (price[7])*qty;
            printf("Total cart Sum: %d\n",sum);
            atta = atta - qty;
            printf("-------------------------------\n");
            break;

         case 9:
            printf("Enter the quantity required for oats: ");
            scanf("%d",&qty);
            if(qty>oats){
                printf("OUT OF STOCK");
                break;
            }
            indsum = (price[8])*qty;
            printf("Price of item for %d Quantities: %d\n",qty,indsum);
            sum = sum + (price[8])*qty;
            printf("Total cart Sum: %d\n",sum);
            oats = oats - qty;
            printf("-------------------------------\n");
            break;

         case 10:
            printf("Enter the quantity required for Juice: ");
            scanf("%d",&qty);
            if(qty>juice){
                printf("OUT OF STOCK");
                break;
            }
            indsum = (price[9])*qty;
            printf("Price of item for %d Quantities: %d\n",qty,indsum);
            sum = sum + (price[9])*qty;
            printf("Total cart Sum: %d\n",sum);
            juice = juice-qty;
            printf("-------------------------------\n");
            break;

         case 0:
            printf("Exiting...\n");
            bill(sum);
            i = 2;
            break;

         default:
            printf("\nPlease Enter correct choice!\n");
            break;

        }
    }
}


void bill(int sum)
{
    system("cls");
    int dis = 0;
    printf("------DEPARTMENT_STORE------\n");
    printf("------------BIll-----------\n");
    printf("Total cart amount: %d\n",sum);
    if(sum>=500){
        dis=sum*0.10;
        int tax = (sum-dis)*0.18;
        printf("\nTotal Discount: %d",dis);
        printf("\nTotal tax %d",tax);
        printf("\nTotal amount after discount: %d",(sum-dis+tax));
    }
    else if( sum < 500)
    {
        int tax = sum*0.18;
        printf("\nTotal Tax: %d",tax);
        printf("\nTotal amount: %d",(sum+tax));
    }
    printf("\n------THANK_YOU------\n");

}

int main()
{
    get_userdata();
    return 0;
}
