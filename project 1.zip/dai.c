#include<stdio.h>
#include<string.h>

struct list{
    int id;
    char itemName[30];
    int price;
    int quantity; 
};

struct Customer {
    char username[30];
    char password[30];
    char name[30];
    char address[30];
};

void display(struct list l[], int size, char cName[], char cAddress[]){
    int total = 0;
    printf("\n\n\n\n");
    printf("\t Pandian stores \n");
    printf("\t-------------- \n");
    printf("\n");
    printf("Name : %s \t Address : %s \n", cName, cAddress);
    printf("\n");
    for (int i = 0; i < size; i++)
    {
        printf("Product: %d\t", l[i].id);
        printf("Name : %s\t", l[i].itemName);
        printf("Price : %d\t", l[i].price);
        printf("Quantity : %d\n", l[i].quantity); 
        printf("------------------------------------------------\n");
        total += (l[i].price * l[i].quantity);
    }

    float tax = 0.18 * total;
    printf("\t\tSubtotal : %d\n", total);
    printf("\t\tTax (18%%) : %.2f\n", tax);
    printf("\t\tTotal : %.2f\n", total + tax);
    printf("\n\n");
    printf("\t Thanks for visiting \n");
    printf("\n\n");
}

int main(){
    printf("Welcome to Pandian Stores\n");

    struct Customer customer;
    printf("Enter your name: ");
    scanf("%s", customer.name);
    printf("Enter your address: ");
    scanf("%s", customer.address);

    char username[30], password[30];
    printf("Please create a username: ");
    scanf("%s", username);
    printf("Please create a password: ");
    scanf("%s", password);

    printf("\nLogin to verify your details:\n");
    printf("Username: ");
    scanf("%s", customer.username);
    printf("Password: ");
    scanf("%s", customer.password);

    if (strcmp(username, customer.username) == 0 && strcmp(password, customer.password) == 0) {
        printf("Login successful!\n");

        int totalItems;
        printf("Enter total items: ");
        scanf("%d", &totalItems);

        struct list l[totalItems];

        for (int i = 0; i < totalItems; i++) {
            l[i].id = (i+1);
            printf("Enter item %d name: ", i+1);
            scanf("%s", l[i].itemName);
            printf("Enter price: ");
            scanf("%d", &l[i].price);
            printf("Enter quantity: "); 
            scanf("%d", &l[i].quantity); 
        }

        display(l , totalItems , customer.name , customer.address);
    } else {
        printf("Invalid username or password. Access denied.\n");
    }

    return 0;
}